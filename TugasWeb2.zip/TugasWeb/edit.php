<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan CRUD PHP</title>
    <link rel="stylesheet" href="assets/bootstrap.min.css">
    <script src="assets/jquery-3.6.1.js"></script>
    <script src="assets/bootstrap.min.js"></script>
</head>
<?php

include "koneksi1.php";

if (isset($_GET['nim'])) {
    $nim = $_GET['nim'];

    $sql = "SELECT * FROM tb_mahasiswa WHERE nim = '$nim'";
    $result = $koneksi->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nim = $row['nim'];
        $nama = $row['nama'];   
        $jk = $row['jk'];
        $tgl_lahir = $row['tgl_lahir'];
        $jurusan = $row['jurusan'];
        $alamat = $row['alamat'];
    }else {
        echo "Data Tidak Ditemukan";
        exit;
    } 
} else {
    echo "Data Parameter Tidak Ditemukan";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $jk = $_POST['jk'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $jurusan = $_POST['jurusan'];
    $alamat = $_POST['alamat'];

    $sql = "UPDATE tb_mahasiswa set nama='$nama', jk='$jk', tgl_lahir='$tgl_lahir', jurusan='$jurusan', alamat='$alamat' where nim='$nim'";


    if ($koneksi->query($sql) === TRUE) {
        echo "<script>
            alert('Data Berhasil Di ubah');
            window.location= 'index.php';
        </script>";
    } else {
        echo "<script>
            alert('Data Gagal Di ubah: " . $koneksi->error . "');
        </script>";
    }
}

?>

<body>
    <div class="container">
        <div class="col-lg-12">
            <header class="bg-info text-white">
                <div class="row">
                    <div class="col-lg-6">
                        <img src="assets/image/logo.png" alt="" width="350px">
                    </div>

                    <div class="col-lg-6">
                        <h3>LAtihan CRUDPHP</h3>
                        <p>Prodi Sistem Informasi</p>
                    </div>
                </div>
            </header>
            <main>
                <h4><u>Edit Data Mahasiswa</u></h4>
                <div class="col-lg-12">
                    <form action="" method="post" id="myform">
                         <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="">NIM</label>
                                    <input type="text" name="nim" class="form-control" value="<?= $nim ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="">Nama</label>
                                    <input type="text" name="nama" class="form-control" value="<?= $nama ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Jenis Kelamin</label>
                                    <br>
                                    <input type="radio" name="jk" value="L" <?php if($jk == 'L') echo "checked"; ?>> Laki-Laki
                                    <input type="radio" name="jk" value="P" <?php if($jk == 'P') echo "checked"; ?>> Perempuan
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="">Tanggal Lahir</label>
                                    <input type="date" name="tgl_lahir" class="form-control"value="<?= $tgl_lahir ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Jurusan</label>
                                    <select name="jurusan" class="form-control">
                                        <option <?php if($jurusan == 'Sistem Informasi') echo 'selected'; ?>>Sistem Informasi</option>
                                        <option  <?php if($jurusan == 'Teknik Informatika') echo 'selected'; ?>>Teknik Informatika</option>
                                        <option  <?php if($jurusan == 'Teknik Mesin') echo 'selected'; ?>>Teknik Mesin</option>
                                        <option  <?php if($jurusan == 'Sistem komunikasi') echo 'selected'; ?>>Sistem Komunikasi</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Alamat</label>
                                    <textarea name="alamat" class="form-control"><?= $alamat ?></textarea>
                                </div>
                            </div>
                            <footer class="py-2">   
                                <button type="submit" class="btn btn-info">ubah</button>
                                <a href="index.php" class="btn btn-danger">kembali</a>
                            </footer>
                        </div>
                    </form>
                </div>
            </main>
            <footer class="bg-info text-center">
                <div class="col-lg-12 py-4 text-white">
                    &copy; 2024 Rivaldo | Universitas Pamulang
                </div>
            </footer>
        </div>
    </div>
    
</body>

</html>