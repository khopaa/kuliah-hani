<?php

session_start();
include '../koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

$query = "SELECT * FROM tb_login where login='$username' and pasword='$password'";
$data = mysqli_query($koneksi, $query);
$cek = mysqli_num_rows($data);

if ($cek > 0) {
    $_SESSION['username'] = $username;
    $_SESSION['status'] = 'login';
    header("location:../index.php");
} else {
    echo "<script>alert('Username/ Password anda salah!!');window.location.href='../login.php';</script>";
}