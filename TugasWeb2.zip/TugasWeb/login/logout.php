<?php
session_start();
session_start();
header('location:../login.php');