<?php

include "koneksi1.php";

if (isset($_GET['nim'])) {
    $nim = $_GET['nim'];

    $sql = "DELETE FROM tb_mahasiswa WHERE nim='$nim'";
    if ($koneksi->query($sql) === TRUE) {
        echo "<script>
            alert('Data Berhasil Di hapus');
            window.location= 'index.php';
        </script>";
    } else {
        echo "<script>
            alert('Data Gagal Di hapus');
            window.location= 'index.php';
        </script>";
    }
} else {
    echo "Data parameter Tidak Ditemukan";
    exit;
}