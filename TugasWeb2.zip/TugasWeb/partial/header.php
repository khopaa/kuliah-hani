<?php
session_start();
if ($_SESSION['status'] != 'login') {
    header('location:./login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project CRUD PHP</title>
    <link rel="stylesheet" href="assets/bootstrap.min.css">
    <link rel="stylesheet" href="assets/datatables.css">
    <script src="assets/bootstrap.min.js"></script>
    <script src="assets/jquery-3.6.1.js"></script>
    <link rel="stylesheet" href="assets/DataTables-1.13.3/css/jquery.dataTables.min.css">
    <script src="assets/DataTables-1.13.3/js/jquery.dataTables.min.js"></script>
</head>
<style>
    body {
        margin: 0;
        display: flex;
        flex-direction: column;
    }

    .navbar {
        z-index: 1030;
    }

    .sidebar {
        position: fixed;
        top: 56px;
        left: 0;
        width: 250px;
        height: calc(100vh - 56px);
        background-color: #343a40;
        color: white;
        padding-top: 15px;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar a{
        color: white;
        text-decoration: none;
        padding: 10px 20px;
        display: block;
    }

    .sidebar a:hover{
        background-color: #495057;
    }

    .main-content{
        margin-left: 250px;
        padding: 20px;
        margin-top: 56px;
    }
</style>

<body>
    <nav class="navbar navbar-expand-lg nav-dark bg-primary fixed-top">
        <div class="container-fluid">
            <a href="index.php" class="navbar-brand text-white">WEBSITE SI UNPAM</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a href="#" class="nav-link active text-white">Welcome Back, <?php echo $_SESSION['username']; ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="sidebar">
        <a href="index.php">Dashboard</a>
        <a href="mahasiswa.php">Data Mahasiswa</a>
        <a href="user.php">Data User</a>
        <a href="./login/logout.php">Logout</a>
    </div>
    <div class="main-content">