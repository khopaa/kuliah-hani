<?php


$server = "localhost";
$user = "root";
$pass = "";
$db = "db_mahasiswa";

$koneksi = mysqli_connect($server,$user,$pass,$db);
if (mysqli_connect_errno()) {
    echo "koneksi ke database gagal" . mysqli_connect_errno();
}