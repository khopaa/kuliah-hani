<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan CRUD PHP</title>
    <link rel="stylesheet" href="assets/bootstrap.min.css">
    <script src="assets/jquery-3.6.1.js"></script>
    <script src="assets/bootstrap.min.js"></script>
</head>
<?php

include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $jk = $_POST['jk'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $jurusan = $_POST['jurusan'];
    $alamat = $_POST['alamat'];

    $sql = "INSERT INTO tb_mahasiswa VALUES('$nim', '$nama', '$jk', '$tgl_lahir', '$jurusan', '$alamat')";

    if ($koneksi->query($sql) === TRUE) {
        echo "<script>
            alert('Data Berhasil Disimpan');
            window.location= 'index.php';
        </script>";
    } else {
        echo "<script>
            alert('Data Gagal Disimpan: " . $koneksi->error . "');
        </script>";
    }
}

?>

<body>
    <div class="container">
        <div class="col-lg-12">
            <header class="bg-info text-white">
                <div class="row">
                    <div class="col-lg-6">
                        <img src="assets/image/logo.png" alt="" width="350px">
                    </div>

                    <div class="col-lg-6">
                        <h3>LAtihan CRUDPHP</h3>
                        <p>Prodi Sistem Informasi</p>
                    </div>
                </div>
            </header>
            <main>
                <h4><u>Add Data Mahasiswa</u></h4>
                <div class="col-lg-12">
                    <form action="" method="post" id="myform">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="">NIM</label>
                                <input type="text" name="nim" class="form-control">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="">Nama</label>
                                <input type="text" name="nama" class="form-control">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="">Jenis Kelamin</label>
                                <br>
                                <input type="radio" name="jk" value="L"> Laki-Laki
                                <input type="radio" name="jk" value="P"> Perempuan
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="">Tanggal Lahir</label>
                                <input type="date" name="tgl_lahir" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Jurusan</label>
                                <select name="jurusan" class="form-control">
                                    <option>Sistem Informasi</option>
                                    <option>Teknik Informatika</option>
                                    <option>Teknik Mesin</option>
                                    <option>Sistem Komunikasi</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Alamat</label>
                                <textarea name="alamat" class="form-control"></textarea>
                            </div>
                        </div>
                        <footer class="py-2">   
                            <button type="submit" class="btn btn-info">Simpan</button>
                            <a href="index.php" class="btn btn-danger">kembali</a>
                        </footer>
                    </div>
                </div>

            </main>
            <footer class="bg-info text-center">
                <div class="col-lg-12 py-4 text-white">
                    &copy; 2024 Rivaldo | Universitas Pamulang
                </div>
            </footer>
        </div>
    </div>
    <script>
    $(document).ready(function() {
        $('#tabel_mhs').DataTable();
    })
    </script>    
</body>

</html>