<?php include 'partial/header.php'; ?>
<h4>Selamat Datang di Website SI Unpam</h4>
<p>Ini adalah konten isi data</p>
<?php include 'partial/footer.php'; ?>