<?php include 'partial/header.php'; ?>
    <div class="container">
        <div class="col-lg-12">
            <main>
                <h4><u>List data mahasiswa</u></h4>
                <div class="col-lg-12">
                    <div class="py-4">
                        <a href="add.php" class="btn btn-info">Add</a>
                    </div>
                    <table id="tabel_mhs" class="table table-bordered" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIM</th>
                                <th>Nama</th>
                                <th>Tanggal Lahir</th>
                                <th>Jenis Kelamin</th>
                                <th>Jurusan</th>
                                <th>Alamat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include 'koneksi.php';
                            $no = 1;
                            $query = "SELECT * FROM tb_mahasiswa";
                            $result = mysqli_query($koneksi, $query);
                            while ($row = mysqli_fetch_assoc($result)) :
                            ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= $row['nim']; ?></td>
                                    <td><?= $row['nama']; ?></td>
                                    <td><?= $row['tgl_lahir']; ?></td>
                                    <td><?= $row['jk']; ?></td>
                                    <td><?= $row['jurusan']; ?></td>
                                    <td><?= $row['alamat']; ?></td>
                                    <td>
                                        <a href="edit.php?nim=<?= $row['nim']; ?>" class="btn btn-success">Edit</a>
                                        <a href="delete.php?nim=<?= $row['nim']; ?>" class="btn btn-danger" onclick="return confirm('Yakin delete data?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#tabel_mhs').DataTable();
        })
    </script>
<?php include 'partial/footer.php'; ?>