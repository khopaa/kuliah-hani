<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="assets/bootstrap.min.css">
</head>
<body>
    <div class="container vh-100 d-flex justify content center align-items-center">
        <div class="card shadow-lg p-4" style="width: 100%; max-width:400px">
            <h3 class="text-center text-primary mb-4">login</h3>
            <form action="login/proded_login.php" method="post">
                <div class="mb-3">
                    <label for="">username</label>
                    <input type="text" class="form-control" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="">password</label>
                    <input type="" class="form-control" name="username" required>
                </div>
</body>
</html>