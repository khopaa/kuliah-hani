<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan CRUD PHP</title>
    <link rel="stylesheet" href="assets/assets/bootstrap.min.css">
    <link rel="stylesheet" href="assets/assets/datatables.min.css">
    <script src="assets/assets/bootstrap.min.js"></script>
    <script src="assets/assets/jquery-3.6.1.js"></script>
    <link rel="stylesheet" href="assets/assets/DataTables-1.12.3/css/jquery.dataTables.min.css">
    <script src="assets/assets/DataTables-1.13.3/js/jquery.dataTables.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="col-lg-12">
            <header class="bg-info text-white">
                <div class="row">
                    <div class="col-lg-6">
                        <img src="assets/assets/image/logo.png" alt="" width="350px">
                    </div>
                    <div class="col-lg-6">
                        <h3>Latihan CRUD PHP</h3>
                        <p>Prodi Sistem Informasi</p>
                    </div>
                </div>
            </header>
            <main>
                <h4><u>Data Pembelian Toko Hanifah</u></h4>
                <div class="col-lg-12">
                    <table id="tabel_mhs" class="table table-bordered" width="100%">
                        <thead>
                            <tr>
                                <th>Tanggal Pembalian</th>
                                <th>ID</th>
                                <th>Kategori</th>
                                <th>no faktur</th>
                                <th>Jenis</th>
                                <th>Jumlah Item</th>
                                <th>Nominal</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </main>
            <footer class="bg-info text-center">
                <div class="col-lg-12 py-4 text-white">
                    &copy; 2024 KKhopa| Universitas Pamulang
                </div>
            </footer>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#tabel_mhs').DataTable();
        })
        </script>
</body>
</html>